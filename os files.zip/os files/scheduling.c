#include<stdio.h>
struct process{
	int id,at,bt,r;
}p[10];
void main()
{
    int gc[50]={0};	
	int run_time=0,total=0;
	int n,i,j,small,k,l=0;
	struct process temp;
	printf("enter the number of processes");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter process id for process %d : ",i+1);
		scanf("%d",&p[i].id);
		printf("enter arrival time for process %d : ",i+1);
		scanf("%d",&p[i].at);
		printf("enter burst time for process %d : ",i+1);
		scanf("%d",&p[i].bt);
	}
	for(i=0;i<n;i++)
	{
	   total+=p[i].bt;
    }
	for(i=0;i<n;i++)
	{
		p[i].r=1;               //setting all processes to not ready state
	}
	while(run_time<total)
	{
		l=0;
		for(i=0;i<n;i++)
		{
			if((p[i].at<=run_time)&&(p[i].r!=2))
			{
				p[i].r=0;         //0 implies process is ready 
				l++;
			}
	    }
		
		
		for(i=0;i<n;i++)          //sorting based on r so that all ready processes are at the front
		{
			small=i;
			for(j=i+1;j<n;j++)
			{
				if(p[j].r<p[small].r)
				small =j;
			}
			temp= p[i];
			p[i]= p[small];
			p[small]=temp;
		}
		
		
		for(i=0;i<l;i++)          //sorting based on burst time so that ready processes are in sjf format
		{
			small=i;
			for(j=i+1;j<l;j++)
			{
				if(p[j].bt<p[i].bt)
				small =j;
			}
			temp= p[i];
			p[i]= p[small];
			p[small]=temp;
		}	
			
		p[0].bt=p[0].bt-1;         //reducing the burst time of smallest process i.e processing
		
		if(p[0].bt==0)             //checking if process is finished
		{
			p[0].r=2;
		}
	gc[run_time]=p[0].id;
	   	
		   if(gc[total]==gc[total-1]){
		   if(gc[run_time]!=gc[run_time-1])
		{
		    printf("  P%d |",gc[run_time]);
            printf("-- %d",run_time);
		}
	}
		
	//	printf("\ndetails : pid :%d,arrival time: %d, current time:%d, current burst time :%d , status:%d",p[0].id,p[0].at,run_time,p[0].bt,p[0].r);
		
		run_time++;
	}
		 printf("  P%d |",gc[run_time-1]);
            printf("-- %d",run_time);
	
 }
	
	

