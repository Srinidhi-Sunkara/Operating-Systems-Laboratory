/*#include<stdio.h>
int main()
{
	int  nparti,nproc,i,small,j,k,c;
	int parti[10],procmem[10],cpart[10],cproc[10];
	printf("\nEnter num of proc:");
	scanf("%d",&nproc);
	printf("\nEnter num of parti:");
	scanf("%d",&nparti);
	printf("\nEnter the partitions:");
	for(i=0;i<nparti;i++)
	{
		scanf("%d",&parti[i]);
	}
	printf("\nEnter the memory req by the proc:");
	for(i=0;i<nproc;i++)
	{
		scanf("%d",&procmem[i]);
	}
	printf("\nFIRST FIT:\n");
	for(i=0;i<nproc;i++)
	{
		int first=parti[0];
		for(j=0;j<nparti;j++)
		{	
			if(parti[j]>=procmem[i] )
			{
				first=parti[j];
				c=j;
				break;
			}	
		}
		//printf("%d",first);
		cproc[i]=c;
		parti[c]=parti[c]-procmem[i];
		printf("%d\t",procmem[i]);
		if(parti[c]<0)
			printf("-\t\tNot Allocated\t-\n");
		else
			printf("%d\t\t%d\t\t%d\n",cproc[i]+1,first,parti[c]);
	}
}*/
//tree
/*
#include<stdio.h>
#include<malloc.h>
#include<string.h>
struct node
{
char name[20];
int type;
struct node *next, *down;
};
// A utility function to create a new BST node
struct node *newNode(char item[],int type1){
struct node *temp = (struct node *)malloc(sizeof(struct node));
strcpy(temp->name,item);
temp->next = temp->down = NULL;
temp->type = type1;
if(type1==1)
printf("New directory %s has been created\n",temp->name);
else
printf("New file %s has been created\n",temp->name);
return temp;
}
struct node *inorder(struct node *root,char p[]){
if (root->next!= NULL && strcmp(root->name,p)!=0){
inorder(root->next,p);
printf("%s ", root->name);
if(root->type==1)
inorder(root->down,p);
}
return root;
}
int find(struct node* node,char *key){
struct node* temp = node;
if(temp!=NULL){
if(strcmp(temp->name,key)==0){
printf("Found %s\n",temp->name);
return 1;
}else{
find(temp->down,key);
find(temp->next,key);
}
}
return 0;
}
struct node* insert(struct node* node, char key[],char par[],int
mode){
// If the tree is empty, return a new node 
if (node == NULL){
printf("The root node is getting created .....\n");
return newNode(key,mode);
}
else{
struct node *temp = NULL;
temp=inorder(node,par);
struct node *temp1 = newNode(key,mode);
if(temp->down==NULL && temp->type ==1){
temp->down = temp1;
if(temp1->type == 2){
printf("File %s successfully inserted\n",temp1->name);
}
else
printf("Directory %s successfully inserted\n",temp1->name);
}else{
temp = temp->down;
while(temp->next!=NULL){
temp = temp->next;
}
temp->next = temp1;
if(temp1->type == 2){
printf("File %s successfully inserted\n",temp1->name);
}else
printf("Directory %s successfully inserted\n",temp1->name);
}
}
return node;
}
int main(){
struct node *root = NULL;
int p=0;
int c=0;
char parent[50][20];
char child[50][20];
char cont = 'y';
root = insert(root, "root","",1);
while(cont == 'y'){
char parDir[20];
char fileOrDir[20];
int t;
printf("Enter parent directory and directory or file name and type (1 for directory and 2 for file)\n");
scanf("%s",parDir);
scanf("%s",fileOrDir);
scanf("%d",&t);
insert(root,fileOrDir,parDir,t);
strcpy(child[c],fileOrDir);
strcpy(parent[p],parDir);
c++;
p++;
printf("Wanna insert more?? \n");
scanf("%s",&cont);
}
char finder[20];
printf("Enter file name to search\n");
scanf("%s",finder);
find(root,finder);
char par[20]; 
char chi[20];
strcpy(chi,finder);

return 0;
}
*/
/*
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main()
{
int f[50], p,i, st, len, j, c, k, a;
//clrscr();
for(i=0;i<50;i++)
f[i]=0;
printf("Enter how many blocks already allocated: ");
scanf("%d",&p);
printf("Enter blocks already allocated: ");
for(i=0;i<p;i++)
{
 scanf("%d",&a);
 f[a]=1;
}
x: printf("Enter index starting block and length: ");
scanf("%d%d", &st,&len);
k=len;
if(f[st]==0)
{
 for(j=st;j<(st+k);j++)
 {
 if(f[j]==0)
 {
 f[j]=1;
 printf("%d-------->%d\n",j,f[j]);
 }
 else
 {
 printf("%d Block is already allocated \n",j);
 k++;
 }
 }
}
else
printf("%d starting block is already allocated \n",st);
printf("Do you want to enter more file(Yes - 1/No - 0)");
scanf("%d", &c);
if(c==1)
 goto x;
else
 exit(0);
getch();
}*/
#include<stdio.h>
#include<stdlib.h>
typedef struct
{
int bno,flag,next;
}block;
block b[200],b1;
main()
{
int rnum();
int i,n,s,s1,p[30],r,k[20];
printf("\nEnter number of programs:");
scanf("%d",&n);
printf("\nEnter the memory block request");
for(i=1;i<=n;i++)
{
printf("\nEnter program requirement");
scanf("%d",&p[i]);
}
for(i=1;i<=n;i++)
{
s=rnum();
b[s].bno=0;
b[s].flag=1;
k[i]=0;
r=p[i]-1;
while(r!=0)
{
s1=rnum();
b[s].next=s1;
b[s1].flag=1;
b[s1].bno=0;
s=s1;
r=r-1;
}
b[s1].next=NULL;
}
printf("\n Starting blocks for program");
for(i=1;i<=n;i++)
printf("\n%5d%5d",i,k[i]);
printf("\n allocated blocks");
for(i=1;i<=200;i++)
{
if(b[i].flag==1)
printf("\n%5d%5d",b[i].bno,b[i].next);
}
}
int rnum()
{
int k,i;
for(i=1;i<=200;i++)
{
k=rand()%200;
if(b[i].flag!=1)
break;
}
return k;
}
