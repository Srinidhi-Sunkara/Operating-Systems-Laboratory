#include<stdio.h>

struct process
{
      char process_name;
      int at, bt, ct, wt, tt, priority;
      int status;
}pq[10];

int limit;

void at_Sorting()
{
      struct process temp;
      int i, j;
      for(i = 0; i < limit - 1; i++)
      {
            for(j = i + 1; j < limit; j++)
            {
                  if(pq[i].at > pq[j].at)
                  {
                        temp = pq[i];
                        pq[i] = pq[j];
                        pq[j] = temp;
                  }
            }
      }
}

void main()
{
      int i, time = 0, bt = 0, largest;
      char c;
      float wait_time = 0, tt = 0, average_wt, average_tt;
      printf("\nEnter Total Number of Processes:\t");
      scanf("%d", &limit);
      for(i = 0, c = 'A'; i < limit; i++, c++)
      {
            pq[i].process_name = c;
            printf("\nEnter Details For Process[%C]:\n", pq[i].process_name);
            printf("Enter Arrival Time:\t");
            scanf("%d", &pq[i].at );
            printf("Enter Burst Time:\t");
            scanf("%d", &pq[i].bt);
            printf("Enter Priority:\t");
            scanf("%d", &pq[i].priority);
            pq[i].status = 0;
            bt = bt + pq[i].bt;
      }
      at_Sorting();
      pq[9].priority = -9999;
      printf("\nProcess Name\tArrival Time\tBurst Time\tPriority\tWaiting Time");
      for(time = pq[0].at; time < bt;)
      {
            largest = 9;
            for(i = 0; i < limit; i++)
            {
                  if(pq[i].at <= time && pq[i].status != 1 && pq[i].priority > pq[largest].priority)
                  {
                        largest = i;
                  }
            }
            time = time + pq[largest].bt;
            pq[largest].ct = time;
            pq[largest].wt = pq[largest].ct - pq[largest].at - pq[largest].bt;
            pq[largest].tt = pq[largest].ct - pq[largest].at;
            pq[largest].status = 1;
            wait_time = wait_time + pq[largest].wt;
            tt = tt + pq[largest].tt;
            printf("\n%c\t\t%d\t\t%d\t\t%d\t\t%d", pq[largest].process_name, pq[largest].at, pq[largest].bt, pq[largest].priority, pq[largest].wt);
      }
      average_wt = wait_time / limit;
      average_tt = tt / limit;
      printf("\n\nAverage waiting time:\t%f\n", average_wt);
      printf("Average Turnaround Time:\t%f\n", average_tt);
}
