/*#include<stdio.h>
int main()
{
	int  nparti,nproc,i,small,j,k,c;
	int parti[10],procmem[10],cpart[10],cproc[10];
	printf("\nEnter num of proc:");
	scanf("%d",&nproc);
	printf("\nEnter num of parti:");
	scanf("%d",&nparti);
	printf("\nEnter the partitions:");
	for(i=0;i<nparti;i++)
	{
		scanf("%d",&parti[i]);
	}
	printf("\nEnter the memory req by the proc:");
	for(i=0;i<nproc;i++)
	{
		scanf("%d",&procmem[i]);
	}
	printf("\nFIRST FIT:\n");
	for(i=0;i<nproc;i++)
	{
		int first=parti[0];
		for(j=0;j<nparti;j++)
		{	
			if(parti[j]>=procmem[i] )
			{
				first=parti[j];
				c=j;
				break;
			}	
		}
		//printf("%d",first);
		cproc[i]=c;
		parti[c]=parti[c]-procmem[i];
		printf("%d\t",procmem[i]);
		if(parti[c]<0)
			printf("-\t\tNot Allocated\t-\n");
		else
			printf("%d\t\t%d\t\t%d\n",cproc[i]+1,first,parti[c]);
	}
}*/
//Bankers algorithm
/*
#include <stdio.h>
#include <stdlib.h>
int main()
{
int Max[10][10], need[10][10], alloc[10][10], avail[10], completed[10], safeSequence[10];
int p, r, i, j, process, count;
count = 0;
printf("Enter the no of processes : ");
scanf("%d", &p);
for(i = 0; i< p; i++)
completed[i] = 0;//none is completed
printf("\n\nEnter the no of resources : ");
scanf("%d", &r);
printf("\n\nEnter the Max Matrix for each process : ");
for(i = 0; i < p; i++)
{
printf("\nFor process %d : ", i + 1);
for(j = 0; j < r; j++)
scanf("%d", &Max[i][j]);
}
printf("\n\nEnter the allocation for each process : ");
for(i = 0; i < p; i++)
{
printf("\nFor process %d : ",i + 1);
for(j = 0; j < r; j++)
scanf("%d", &alloc[i][j]);
}
printf("\n\nEnter the Available Resources : ");
for(i = 0; i < r; i++)
scanf("%d", &avail[i]);
for(i = 0; i < p; i++)
for(j = 0; j < r; j++)
need[i][j] = Max[i][j] - alloc[i][j];
do
{ 
printf("\n Max matrix:\tAllocation matrix:\n");//for printing 
for(i = 0; i < p; i++)
{
for( j = 0; j < r; j++)
printf("%d ", Max[i][j]);
printf("\t\t");
for( j = 0; j < r; j++)
printf("%d ", alloc[i][j]);
printf("\n");
}
process = -1;//initializing process to consider a process which is not completed
for(i = 0; i < p; i++)
{
  if(completed[i] == 0)//if not completed
  {
    process = i ;
	for(j = 0; j < r; j++)
	{
		if(avail[j] < need[i][j])//if available is less than needed break to check next process
		{
			process = -1;
		break; 
		}
	}
  }
 if(process != -1)//if a process i is allocated
 break;
}//end of for loop
if(process != -1)
{
printf("\nProcess %d runs to completion!", process + 1);
safeSequence[count] = process + 1;//has safe sequence
count++;
 for(j = 0; j < r; j++)
 {
  avail[j] += alloc[process][j];//once completed the process releases all its processes
  alloc[process][j] = 0;
  Max[process][j] = 0;
  completed[process] = 1;
 }
}
}while(count != p && process != -1);
if(count == p)
{
printf("\nThe system is in a safe state!!\n");
printf("Safe Sequence : < ");
for( i = 0; i < p; i++)
printf("%d ", safeSequence[i]);
printf(">\n");
}
else
printf("\nThe system is in an unsafe state!!");
}*/
//FIFO
/*#include<stdio.h> 
#include<stdlib.h> 
int i,j,nof,nor,flag=0,ref[50],frm[50],pf=0,victim=
-1; 
void main() 
{ 
 printf("\n \t\t\t FIFO PAGE REPLACEMENT ALGORITHM"); 
 printf("\n Enter no.of frames:"); 
 scanf("%d",&nof); 
 printf("Enter number of reference string:\n"); //no of elements in the reference string
 scanf("%d",&nor); 
 printf("\n Enter the reference string:"); //enter reference string
 for(i=0;i<nor;i++) 
 scanf("%d",&ref[i]); 
 printf("\nThe given reference string:"); //printing reference string
 for(i=0;i<nor;i++) 
 printf("%4d",ref[i]); 
 for(i=1;i<=nof;i++) //intialize all frames to -1 ie no one is allocated
 frm[i]=-1; 
 printf("\n"); 
 for(i=0;i<nor;i++) 
 { 
   flag=0; 
   printf("\n\t Reference np%d->\t",ref[i]); 
   for(j=0;j<nof;j++) 
   { 
     if(frm[j]==ref[i]) 
     { 
       flag=1; //it is found
       break; 
     }
   } 
   if(flag==0) //if not found
   { 
     pf++; //page fault 
     victim++; //victim increase
     victim=victim%nof; //cycle
     frm[victim]=ref[i]; //placing
     for(j=0;j<nof;j++) //printing content of column
     printf("%4d",frm[j]); 
   } 
 } 
 printf("\n\n\t\t No.of pages faults...%d",pf); 

} */
//lru algorithm
/*#include<stdio.h> 
#include<stdlib.h> 
int i,j,nof,nor,flag=0,ref[50],frm[50],pf=0,victim=
-1; 
int recent[10],lrucal[50],count=0; 
int lruvictim(); 
void main() 
{ 
  printf("\n\t\t\t LRU PAGE REPLACEMENT ALGORITHM")
; 
  printf("\n Enter no.of Frames:"); 
  scanf("%d",&nof); 
  printf(" Enter no.of reference string:"); 
  scanf("%d",&nor); 
  printf("\n Enter reference string:"); 
  for(i=0;i<nor;i++) 
  scanf("%d",&ref[i]); 
 // printf("\n\n\t\t LRU PAGE REPLACEMENT ALGORITHM "
//); 
  printf("\n\t The given reference string:"); 
  printf("\n......................................"); 
  for(i=0;i<nor;i++) 
  printf("%4d",ref[i]); 
  for(i=1;i<=nof;i++) 

  { 
    frm[i]=-1; //initially are frames are empty
    lrucal[i]=0; //lru are 0s
  } 
  for(i=0;i<10;i++) 
   recent[i]=0; //all recents are zeros
printf("\n"); 
   for(i=0;i<nor;i++) 
   { 
     flag=0; 
     printf("\n\t Reference NO %d->\t",ref[i]); 
     for(j=0;j<nof;j++) 
     {      
        if(frm[j]==ref[i]) 
       { 
           flag=1; 
            break; 
       } 
     } 
     if(flag==0) 
     { 
       count++; //counts no of frames occupied
       if(count<=nof) //ie frame is free
       victim++; 
       else //frame is not free
       victim=lruvictim(); 
       pf++; //page fault
       frm[victim]=ref[i]; 
       for(j=0;j<nof;j++) 
       printf("%4d",frm[j]); 
     } 
     recent[ref[i]]=i; //recent use of the page
   } 
   printf("\n\n\t No.of page faults...%d",pf); 

} 
int lruvictim() 
{ 
  int i,j,temp1,temp2; 
  for(i=0;i<nof;i++) 
  { 
    temp1=frm[i]; 
    lrucal[i]=recent[temp1]; 
  } 
  temp2=lrucal[0]; 
  for(j=1;j<nof;j++) 
  { 
    if(temp2>lrucal[j]) 
    temp2=lrucal[j]; 
  } 
  for(i=0;i<nof;i++) 
  if(ref[temp2]==frm[i]) 
  return i; 
  
} */
//optimal page replacement
/*
#include<stdio.h>
 
int main()
{
    int no_of_frames, no_of_pages, frames[10], pages[30], temp[10], flag1, flag2, flag3, i, j, k, pos, max, faults = 0;
    printf("Enter number of frames: ");
    scanf("%d", &no_of_frames);
    
    printf("Enter number of pages: ");
    scanf("%d", &no_of_pages);
    
    printf("Enter page reference string: ");
    
    for(i = 0; i < no_of_pages; ++i){
        scanf("%d", &pages[i]);
    }
    
    for(i = 0; i < no_of_frames; ++i){
        frames[i] = -1;
    }
    
    for(i = 0; i < no_of_pages; ++i){
        flag1 = flag2 = 0;
        
        for(j = 0; j < no_of_frames; ++j){
            if(frames[j] == pages[i]){//ie page is found in the frame
                   flag1 = flag2 = 1;
                   break;
               }
        }
        
        if(flag1 == 0)
		{
            for(j = 0; j < no_of_frames; ++j){
                if(frames[j] == -1){//checks for empty frame
                    faults++;
                    frames[j] = pages[i];
                    flag2 = 1;
                    break;
                }
            }    
        }
        
        if(flag2 == 0)
		{
        	flag3 =0;
        	
            for(j = 0; j < no_of_frames; ++j)
			{
            	temp[j] = -1;
            	
            	for(k = i + 1; k < no_of_pages; ++k)//checks other pages in the string
				{
            		if(frames[j] == pages[k])
					{
            			temp[j] = k;  //first found
            			break;
            		}
            	}
            }
            
            for(j = 0; j < no_of_frames; ++j)
			{
            	if(temp[j] == -1)//page not found in the reference string
				{
            		pos = j;
            		flag3 = 1;
            		break;
            	}
            }
            
            if(flag3 ==0)//page is found in the reference string
			{
            	max = temp[0];
            	pos = 0;
            	
            	for(j = 1; j < no_of_frames; ++j){
            		if(temp[j] > max){
            			max = temp[j];
            			pos = j;
            		}
            	}            	
            }
			
			frames[pos] = pages[i];
			faults++;
        }
        
        printf("\n");
        
        for(j = 0; j < no_of_frames; ++j)//for printing the frames 
		{
            printf("%d\t", frames[j]);
        }
    }
    
    printf("\n\nTotal Page Faults = %d", faults);
    
    return 0;
}  */
//single level directory
/*
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
void main()
{
int i,ch;
char dname[10],fname[10][10];
int fcnt;
char f[30];//to find a file
fcnt = 0;
printf("\nEnter name of directory -- ");
scanf("%s",dname);
while(1)
{
 printf("\n\n1. Create File\t2. Delete File\t3. Search File \n 4. Display Files\t5. Exit\nEnter your choice -- ");
 scanf("%d",&ch);
 switch(ch)
 {
   case 1: printf("\nEnter the name of the file -- ");
    scanf("%s",fname[fcnt]);
    fcnt++;
   break;
  case 2: printf("\nEnter the name of the file -- ");
   scanf("%s",f);
   for(i=0;i<fcnt;i++)
   {
     if(strcmp(f, fname[i])==0)
    {
      printf("File %s is deleted ",f);
      strcpy(fname[i],fname[fcnt-1]);
      break;
    }
   }
   if(i==fcnt) printf("File %s not found",f);
   else
     fcnt--;
   break;
  case 3: printf("\nEnter the name of the file -- ");
    scanf("%s",f);
    for(i=0;i<fcnt;i++)
    {
     if(strcmp(f, fname[i])==0)
     {
      printf("File %s is found ", f);
    break;
    }
   }
  if(i==fcnt)
    printf("File %s not found",f);
  break;
  case 4: if(fcnt==0)
    printf("\nDirectory Empty");
    else
    {
      printf("\nThe Files are -- ");
      for(i=0;i<fcnt;i++)
       printf("\t%s",fname[i]);
    }
   break;
  default: exit(0);
  }
 }
}*/ 
//two level directory
/*#include<string.h>
#include<stdlib.h>
#include<stdio.h>
struct
{
 char dname[10],fname[10][10];
 int fcnt;
}dir[10];
void main()
{
 int i,ch,dcnt,k;
 char f[30], d[30];
 dcnt=0;
 while(1)
 {
   printf("\n\n1. Create Directory\t2. Create File\t3. Delete File");
   printf("\n4. Search File\t\t5. Display\t6. Exit\tEnter your choice -- ");
   scanf("%d",&ch);
   switch(ch)
   {
    case 1: printf("\nEnter name of directory -- ");
      scanf("%s", dir[dcnt].dname);
      dir[dcnt].fcnt=0;//initializing the file count
      dcnt++;//incrementing the directory count
      printf("Directory created");
      break;
    case 2: printf("\nEnter name of the directory -- ");
          scanf("%s",d);
          for(i=0;i<dcnt;i++)
          if(strcmp(d,dir[i].dname)==0)
          {
            printf("Enter name of the file -- ");
            scanf("%s",dir[i].fname[dir[i].fcnt]);
            dir[i].fcnt++;//increase the file count
            printf("File created");
            break;
          }
          if(i==dcnt)
			printf("Directory %s not found",d);
		break;
    case 3: printf("\nEnter name of the directory -- ");
          scanf("%s",d);
		for(i=0;i<dcnt;i++)
		{
			if(strcmp(d,dir[i].dname)==0)
			{
				printf("Enter name of the file -- ");
				scanf("%s",f);
				for(k=0;k<dir[i].fcnt;k++)
				{
					if(strcmp(f, dir[i].fname[k])==0)
					{
						printf("File %s is deleted ",f);
						dir[i].fcnt--;
						strcpy(dir[i].fname[k],dir[i].fname[dir[i].fcnt]);
						goto jmp;
 					}
				}
				printf("File %s not found",f);
					goto jmp;
			}
		}
		printf("Directory %s not found",d);
		jmp :
		break;
	case 4: printf("\nEnter name of the directory -- ");
		scanf("%s",d);
		for(i=0;i<dcnt;i++)
		{
			if(strcmp(d,dir[i].dname)==0)
			{
				printf("Enter the name of the file -- ");
				scanf("%s",f);
				for(k=0;k<dir[i].fcnt;k++)
				{
					if(strcmp(f, dir[i].fname[k])==0)
					{
						printf("File %s is found ",f);
						goto jmp1;
					}
				}
				printf("File %s not found",f);
				goto jmp1;
			}
		}
		printf("Directory %s not found",d);
		jmp1: break;
	case 5: if(dcnt==0)
			printf("\nNo Directory's ");
			else
			{
				printf("\nDirectory\tFiles");
				for(i=0;i<dcnt;i++)
				{
					printf("\n%s\t\t",dir[i].dname);
					for(k=0;k<dir[i].fcnt;k++)
						printf("\t%s",dir[i].fname[k]);
				}
			}
		break;
	default:exit(0);
	}	
  }
}*/

//FCFS ALGORITHM
#include<stdio.h>
struct fc
{
	int at;
	int bt;
	int st;
	int ft;
};
void main()
{
	int n,wait[10],turn[10],i,j,avgt=0,avgw=0;
	printf("enter no of process");
	scanf("%d",&n);
	struct fc a[n],temp;
	for(i=0;i<n;i++)
	{
		printf("process %d details",i+1);
		printf("\nenter the arrival time:");
		scanf("%d",&a[i].at);
		printf("\nenter the burst time:");
		scanf("%d",&a[i].bt);
	}
	printf("\n\tjob\tburst\tAT\tstart\tfinish\t WT\t TAT");
	for(i=0;i<n-1;i++)
	{
		for(j=1;j<n;j++)
		{
			if(a[i].at>a[j].at)
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	a[0].st=a[0].at;
    for(i=0;i<n;i++)
    {
    	a[i+1].st=a[i].ft=a[i].st+a[i].bt;
    	 wait[i]= a[i].st-a[i].at ;
         turn[i]=a[i].ft-a[i].at;
         printf("\n\t %d\t %d\t %d\t %d\t %d\t %d\t %d ", i, a[i].bt, a[i].at, a[i].st,
a[i].ft, wait[i], turn[i]);
 		avgt+=turn[i];
 		avgw+=wait[i];
    }
    printf("\naverage waiting time %d",avgw/n);
    printf("\naverage turnaround time %d",avgt/n);
    
	
}
//SJF
/*
#include<stdio.h>
struct fc
{
	int at;
	int bt;
	int st;
	int ft;
};
int n,wait[10],turn[10],i,j,avgt=0,avgw=0,start=0,count=0;
struct fc temp;
void sort(struct fc[],int,int);
void main()
{
	
	printf("enter no of process");
	scanf("%d",&n);
	struct fc a[n];
	for(i=0;i<n;i++)
	{
		printf("process %d details",i+1);
		printf("\nenter the arrival time:");
		scanf("%d",&a[i].at);
		printf("\nenter the burst time:");
		scanf("%d",&a[i].bt);
	}
	start=0;
	count=1;
	i=0;
	while(i<n)
	{
		if(a[i].at==a[i+1].at)
		{
		  count++;
		  //printf("In loop");
		  i++;
	    }
		else
		{
				//printf("in loop");
			//sort(a,start,count);
			for(i=start;i<count-1;i++)
	{
		for(j=i+1;j<count;j++)
		{
			if(a[i].bt>a[j].bt)
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
		
			 start=i;
			 count=1;
			 i++;
		}
		
	}
	
	printf("\n\tjob\tburst\tAT\tstart\tfinish\t WT\t TAT");

	a[0].st=a[0].at;
    for(i=0;i<n;i++)
    {
    	a[i+1].st=a[i].ft=a[i].st+a[i].bt;
    	 wait[i]= a[i].st-a[i].at ;
         turn[i]=a[i].ft-a[i].at;
         printf("\n\t %d\t %d\t %d\t %d\t %d\t %d\t %d ", i, a[i].bt, a[i].at, a[i].st,
             a[i].ft, wait[i], turn[i]);
 		avgt+=turn[i];
 		avgw+=wait[i];
    }
    printf("\naverage waiting time %d",avgw/n);
    printf("\naverage turnaround time %d",avgt/n);
    
	
}*/

//sjf non pre
/*#include<stdio.h>
#include<conio.h>
struct process
{
int pid;
int bt;
int wt;
int tt;
}p[10],temp;
int main()
{
int i,j,n,totwt,tottt;
float avg1,avg2;
clrscr();
printf("\nEnter the number of process:\t");
scanf("%d",&n);
for(i=1;i<=n;i++)
{
p[i].pid=i;
printf("\nEnter the burst time:\t");
scanf("%d",&p[i].bt);
}
for(i=1;i<n;i++){
for(j=i+1;j<=n;j++)
{
if(p[i].bt>p[j].bt)
{ 
temp.pid=p[i].pid;
p[i].pid=p[j].pid;
p[j].pid=temp.pid;
temp.bt=p[i].bt;p[i].bt=p[j].bt;
p[j].bt=temp.bt;
}}}
p[1].wt=0;
p[1].tt=p[1].bt+p[1].wt;
i=2;
while(i<=n){
p[i].wt=p[i-1].bt+p[i-1].wt;
p[i].tt=p[i].bt+p[i].wt;
i++;
}
i=1;
totwt=tottt=0;
printf("\nProcess id \tbt \twt \ttt");
while(i<=n){
printf("\n\t%d \t%d \t%d
t%d\n",p[i].pid,p[i].bt,p[i].wt,p[i].tt);
totwt=p[i].wt+totwt;
tottt=p[i].tt+tottt;
i++;
}
avg1=totw
t/n;
avg2=tott
t/n; 
printf("\nAVG1=%f\t
AVG2=%f",avg1,avg2); getch();
return 0; } 
*/
//paging hardware
/*
#include<stdio.h>
void main()
{
	int np,la,pas,nf,ps,fs,las,pa,i,j,k,offset,pno;
	int allocation[20],start[20];
	pas=32;
	las=16;
	ps=4;
	np=las/ps;
	fs=ps;
	nf=pas/fs;
	start[0]=4000;
	for(i=0;i<nf;i++)
	{
		allocation[i]=-1;
		start[i+1]=start[i]+4;
	}
	printf("\nfno pno fadre\n");
	for(i=0;i<nf;i++)
	{
		printf("\n%d  %d  %d\n",i,allocation[i],start[i]);
	}
	printf("after paging");
	j=rand()%nf;
	k=0;
	while(allocation[j]==-1&&k<np)
	{
		allocation[j]=k;
		j=rand()%nf;
		k++;
	}
		printf("\nfno pno fadre\n");
	for(i=0;i<nf;i++)
	{
		printf("\n%d  %d  %d\n",i,allocation[i],start[i]);
	}
	printf("enter la");
	scanf("%d",&la);
	pno=la/ps;
	offset=la%ps;
	if(la<las){
	
	for(i=0;i<nf;i++)
	{
		if(allocation[i]==pno)
		 {
		 pa=start[i]+offset;
		 printf("pa %d",pa);}
	}
   }
   else
   {
   	printf("invalid");
	 }  
}
	
*/
//first fit
/*
#include<stdio.h>
void main()
{
	int procmem[10],parti[10],i,j,np,npart,first,c,cproc[10];
	printf("no of process");
	scanf("%d",&np);
	printf("enter the procmem required");
	for(i=0;i<np;i++)
	{
		
		scanf("%d",&procmem[i]);
	}
	printf("enter the no of partitions");
	scanf("%d",&npart);
	printf("enter the partitions");
	for(i=0;i<npart;i++)
	{
		scanf("%d",&parti[i]);
	}
	for(i=0;i<np;i++)
	{
		first=parti[0];
		for(j=0;j<npart;j++)
		{
			if(parti[j]>=procmem[i])
			{
				first=parti[j];
				c=j;
				break;
			}
		}
		cproc[i]=j;
		parti[c]-=procmem[i];
		if(parti[c]<0)
		{
			printf("not allocated");
		}
		else
		{
			printf("%d \t %d \t %d\n",cproc[i]+1,first,parti[c]);
		}
	}
}*/
//best fit
/*#include<stdio.h>
void main()
{
	int procmem[10],parti[10],i,j,np,npart,small,c,cproc[10],cpart[10];
	printf("no of process");
	scanf("%d",&np);
	printf("enter the procmem required");
	for(i=0;i<np;i++)
	{
		
		scanf("%d",&procmem[i]);
	}
	printf("enter the no of partitions");
	scanf("%d",&npart);
	printf("enter the partitions");
	for(i=0;i<npart;i++)
	{
		scanf("%d",&parti[i]);
	}
	for(i=0;i<np;i++)
	{
		for(j=0;j<npart;j++)
		{
			if(parti[j]>=procmem[i])
			cpart[j]=parti[j];
			else
			cpart[j]=9999;
		}
		small=cpart[0];
		for(j=0;j<npart;j++)
		{
			if(cpart[i]<small)
			{
				c=j;
				small=cpart[j];
			}
		}
		cproc[i]=j;
		parti[c]-=procmem[i];
		if(parti[c]<0)
		{
			printf("%d not allocated\n",i);
		}
		else
		{
			printf("%d \t %d \t %d\n",i+1,small,parti[c]);
		}
	}
}*/
//worst fit
/*#include<stdio.h>
void main()
{
	int procmem[10],parti[10],i,j,np,npart,first,c,cproc[10];
	printf("no of process");
	scanf("%d",&np);
	printf("enter the procmem required");
	for(i=0;i<np;i++)
	{
		
		scanf("%d",&procmem[i]);
	}
	printf("enter the no of partitions");
	scanf("%d",&npart);
	printf("enter the partitions");
	for(i=0;i<npart;i++)
	{
		scanf("%d",&parti[i]);
	}
	for(i=0;i<np;i++)
	{
		first=parti[0];
		for(j=0;j<npart;j++)
		{
			if(parti[j]>procmem[i])
			{
				first=parti[j];
				c=j;
			}
		}
		cproc[i]=j;
		parti[c]-=procmem[i];
		if(parti[c]<0)
		{
			printf("not allocated");
		}
		else
		{
			printf("%d \t %d \t %d\n",cproc[i]+1,first,parti[c]);
		}
	}
}*/
//ipc using pipes
/*#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/time.h>
int main()
{
	int fd1[2],fd2[2],pid,pid1;
	char a[30],b[30],c[30];
	if(pipe(fd1)==0 && pipe(fd2)==0)
	{
		pid=fork();
		if(pid==0)
		{
			printf("child 1");
			printf("\n enter the string :");
			scanf("%s",a);
			close(fd1[0]);
			write(fd1[1],a,sizeof(a));
		}
		else
		{
			wait(0);
			pid1=fork();
			if(pid1!=0)
			{
			
				printf("child 2");
				close(fd2[1]);
				read(fd2[0],c,sizeof(c));
				printf("string read by child2 is %s",c);
				
			}
			else
			{
				printf("in parent process");
				close(fd1[1]);
				read(fd1[0],b,sizeof(b));
				close(fd2[0]);
				write(fd2[1],b,sizeof(b));
			}
		}
	}
	else
	printf("not created");
  return 0;
}*/
//sjf pre
/*
#include<stdio.h>
struct process
{
	int id,at,bt,r;
}p[10];
void main()
{
	int l,n,i,small,j,runtime=0,total=0;
	struct process temp;
	printf("enter the no of process:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter at and bt for process %d: ",i+1);
		scanf("%d %d",&p[i].at,&p[i].bt);
		p[i].r=1;
		total+=p[i].bt;
		p[i].id=i+1;
	}
	while(runtime<total)
	{
		l=0;
		for(i=0;i<n;i++){
			if((p[i].at<=runtime)&&(p[i].r!=2))
			{
				p[i].r=0;
				l++;
			}
		}
		for(i=0;i<n;i++)
		{
			small=i;
			for(j=i+1;j<n;j++)
			{
				if(p[small].r>p[j].r)
				small=j;
			}
			temp=p[small];
			p[small]=p[i];
			p[i]=temp;
		}
	
		for(i=0;i<l;i++)
		{
			small=i;
			for(j=i+1;j<l;j++)
			{
				if(p[j].bt<p[i].bt)
				small=j;
			}
			temp=p[small];
			p[small]=p[i];
			p[i]=temp;
		}
		p[0].bt=p[0].bt-1;
		if(p[0].bt==0)
		{
					p[0].r=2;
		}
		printf("\nprocess id %d runtime %d",p[0].id,runtime);
		runtime++;
		
		
	}
	
}*/
//sjf non p
/*#include<stdio.h>
struct process
{
	int id,at,bt,r;
}p[10];
void main()
{
	int l,n,i,small,j,runtime=0,total=0;
	struct process temp;
	printf("enter the no of process:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter at and bt for process %d: ",i+1);
		scanf("%d %d",&p[i].at,&p[i].bt);
		p[i].r=1;
		total+=p[i].bt;
		p[i].id=i+1;
	}
	while(runtime<total)
	{
		l=0;
		for(i=0;i<n;i++){
			if((p[i].at<=runtime)&&(p[i].r!=2))
			{
				p[i].r=0;
				l++;
			}
		}
		for(i=0;i<n;i++)
		{
			small=i;
			for(j=i+1;j<n;j++)
			{
				if(p[small].r>p[j].r)
				small=j;
			}
			temp=p[small];
			p[small]=p[i];
			p[i]=temp;
		}
	
		for(i=0;i<l;i++)
		{
			small=i;
			for(j=i+1;j<l;j++)
			{
				if(p[j].bt<p[i].bt)
				small=j;
			}
			temp=p[small];
			p[small]=p[i];
			p[i]=temp;
		}
		runtime=runtime+p[0].bt;
		printf("\nprocess id %d runtime %d",p[0].id,runtime);
		
		p[0].bt=0;
		if(p[0].bt==0)
		{
					p[0].r=2;
		}
		
		
		
	}
	
}*/
//priority pre
/*
#include<stdio.h>
struct process
{
	int id,at,bt,r,p;
}p[10];
void main()
{
	int l,n,i,small,j,runtime=0,total=0;
	struct process temp;
	printf("enter the no of process:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter p,at and bt for process %d: ",i+1);
		scanf("%d %d %d",&p[i].p,&p[i].at,&p[i].bt);
		p[i].r=1;
		total+=p[i].bt;
		p[i].id=i+1;
	}
	while(runtime<total)
	{
		l=0;
		for(i=0;i<n;i++){
			if((p[i].at<=runtime)&&(p[i].r!=2))
			{
				p[i].r=0;
				l++;
			}
		}
		for(i=0;i<n;i++)
		{
			small=i;
			for(j=i+1;j<n;j++)
			{
				if(p[small].r>p[j].r)
				small=j;
			}
			temp=p[small];
			p[small]=p[i];
			p[i]=temp;
		}
	
		for(i=0;i<l;i++)
		{
			small=i;
			for(j=i+1;j<l;j++)
			{
				if(p[j].p<p[i].p)
				small=j;
			}
			temp=p[small];
			p[small]=p[i];
			p[i]=temp;
		}
		p[0].bt=p[0].bt-1;
		if(p[0].bt==0)
		{
					p[0].r=2;
		}
	
		runtime++;
			printf("\nprocess id %d runtime %d",p[0].id,runtime);
		
		
	}
	
}*/
/*
#include<stdio.h>
struct process
{
	int id,at,bt,r,p;
}p[10];
void main()
{
	int l,n,i,small,j,runtime=0,total=0;
	struct process temp;
	printf("enter the no of process:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter p,at and bt for process %d: ",i+1);
		scanf("%d %d %d",&p[i].p,&p[i].at,&p[i].bt);
		p[i].r=1;
		total+=p[i].bt;
		p[i].id=i+1;
	}
	while(runtime<total)
	{
		l=0;
		for(i=0;i<n;i++){
			if((p[i].at<=runtime)&&(p[i].r!=2))
			{
				p[i].r=0;
				l++;
			}
		}
		for(i=0;i<n;i++)
		{
			small=i;
			for(j=i+1;j<n;j++)
			{
				if(p[small].r>p[j].r)
				small=j;
			}
			temp=p[small];
			p[small]=p[i];
			p[i]=temp;
		}
	
		for(i=0;i<l;i++)
		{
			small=i;
			for(j=i+1;j<l;j++)
			{
				if(p[j].p<p[i].p)
				small=j;
			}
			temp=p[small];
			p[small]=p[i];
			p[i]=temp;
		}
		runtime=runtime+p[0].bt;
		p[0].bt=0;
		if(p[0].bt==0)
		{
					p[0].r=2;
		}
	
		
			printf("\nprocess id %d runtime %d",p[0].id,runtime);
		
		
	}
	
}*/

