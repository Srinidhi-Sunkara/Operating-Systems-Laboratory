#include<stdio.h>
typedef struct process
{
	int id;
	int arrivaltime;
	int bursttime;
	int priority;
}process;
typedef struct gant
{
	int id;
	int time;
	int arrival;
	int burst;
}gant;
int sort(process src[],int start,int end)
{
	int i=0;
	process min;
	int j=0;
	if(start==end)
	return 0;
	for(i=start;i<=end;i++)
	{
		min=src[i];
		for(j=i+1;j<=end;j++)
		{
			if(src[j].arrivaltime!=min.arrivaltime)
			continue;
			if(src[j].priority<min.priority)
			{
				min=src[j];
				src[j]=src[i];
				src[i]=min;
			}
		}
	}
	return 0;
}
int main()
{
	printf("\t\t Priority Scheduling Pre-Emptive");
	printf("\n\n");
	int arrivarray[50]={0};
	int burst[50]={0};
	process p[50];
	process temp;
	int i,j,k,n;
	printf("\n enter the number of process: ");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter the process %d details: ",i+1);
		p[i].id=i+1;
		printf("enter the arrival time");
		scanf("%d",)
	}
}
