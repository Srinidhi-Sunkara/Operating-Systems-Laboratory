#include<stdio.h>
int main()
{
 int i, j, n, temp, temp1, start[10], finish[10], burst[10], arrival[10], wait[10], turn[10],
sum_wait = 0, sum_turn = 0, process[10], priority[10];
 printf("Enter the number of jobs ");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
 printf("Enter the %d th burst time and priority",i);
 scanf("%d %d",&burst[i], &priority[i]);
process[i]=i;
arrival[i]=0;
 }
 start[0] = arrival[0];
 for(i=0;i<n;i++)
 for(j=i+1;j<n;j++)
 if(priority [i] > priority [j])
 {
temp1=process[i];
process[i] = process[j];
process[j] = temp1;

temp = burst[i];
 burst[i] = burst[j];
 burst[j] = temp;
temp = priority [i];
 priority [i] = priority [j];
 priority[j] = temp;
 }
 printf("\n\tjob\tburst\tAT\t priority\tstart\tfinish\tWT\tTAT");
 for(i=0;i<n;i++)
 {
 start[i+1] = finish[i] = start[i]+burst[i] ;
 turn[i]= finish[i]-start[i];
 wait[i]= start[i]-arrival[i];
 printf("\n\t %d\t%d\t%d\t%d\t%d\t%d\t %d ", process[i], burst[i], arrival[i],
start[i], finish[i], wait[i], turn[i]);
 }
 for(i=0;i<n;i++)
 {
 sum_turn += turn[i];
 sum_wait += wait[i];
 }
 printf("\n\t Avg turn around = %d\n\t Avg waiting time =
%d\n",(sum_turn/n),(sum_wait/n));
}

