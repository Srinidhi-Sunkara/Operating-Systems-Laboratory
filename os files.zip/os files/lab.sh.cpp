echo enter a number
read n
for((i=$n;i>1;i--))
do
  fact=$((fact*i));
done
echo $fact;
 
 
echo enter a number
read n
t=$n
sum=0
r=0
while($t -gt 0)
do
 	r=`expr $t % 10`;
 	mul=`expr $r \* $r \* $r`;
 	sum=`expr $sum + $mul`;
 	t=`expr $t/10`;
done
if($sum = $n)
then
   echo"an";
else
   echo"no";
fi;
