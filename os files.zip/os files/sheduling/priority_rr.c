//to implement process scheduling algorithms - FCFS, SJF
#include<stdio.h>
#include<stdlib.h>
#include"arr_queue.h"

typedef struct{
	int process_ID;
	int arr_time;
	int burst_time;
	int priority;
}process;

typedef struct{
	int process_ID;
	int st_time;
	int end_time;
}gantt_chart;


void print_gantt(gantt_chart *gantt, int nop)
{
    int i;
	printf("\nGANTT CHART-\n");
    for(i=0;i<nop;i++)
    {
        if(i!=0 && gantt[i].st_time==gantt[i-1].end_time)
            printf("|P%d\t",gantt[i].process_ID);
        else if(i!=0)
            printf("|\t|P%d\t",gantt[i].process_ID);
        else if(gantt[i].st_time!=0)
        {
            printf("|\t");
            printf("|P1\t");
        }
        else
            printf("|P1\t");
    }
    printf("|\n0");
	for(i=0; i<nop;i++)
	{
        if(i!=0 && gantt[i].st_time==gantt[i-1].end_time)
            printf(" \t%d ",gantt[i].end_time);
        else if(i!=0)
            printf(" \t%d\t%d ",gantt[i].st_time,gantt[i].end_time);
        else if(gantt[i].st_time!=0)
        {
            printf("\t \t%d ",gantt[i].end_time);
        }
        else
            printf(" \t%d ",gantt[i].end_time);
	}
	printf("\n\n");
}

void print_table(int nop, process *prcs, int *waiting_time, int *turnaround_time)
{
	int tot_waiting_time=0, tot_turnaround_time=0;
	printf("\nPROCESS TABLE-\n");
    printf(" ________________________________________________________________________\n");
    printf("|PROCESS ID|ARRIVAL TIME|BURST TIME|PRIORITY|WAITING TIME|TURNAROUND TIME|\n");
    printf("|__________|____________|__________|________|____________|_______________|\n");
    for(int i=0;i<nop;i++)
    {
        printf("|P%-9d|%12d|%10d|%8d|%12d|%15d|\n",
                prcs[i].process_ID,
                prcs[i].arr_time,
                prcs[i].burst_time,
		prcs[i].priority,
                waiting_time[i],
                turnaround_time[i]);
		tot_waiting_time+=waiting_time[i];
		tot_turnaround_time+=turnaround_time[i];
    }
	printf("_________________________________________________________________________\n\n");
	printf("Average Waiting Time:%-10.2f\n",(float)tot_waiting_time/nop);
	printf("Average Turnaround Time:%-10.2f\n\n",(float)tot_turnaround_time/nop);

}


int highest_priority(int nop, process *prcs, int tot_time){
    int hp=-2,i;
    for(i=0;i<nop;i++)
    {
        if(prcs[i].arr_time>-1 && (tot_time - prcs[i].arr_time)>=0)
        {
            if(hp!=-2 && prcs[i].priority < prcs[hp].priority)
                hp=i;
            else if(hp==-2)
                hp=i;
        }
    }
    return hp;
}


void priority_NP(int nop, process *prcs)
{
gantt_chart gantt[nop];
int waiting_time[nop], turnaround_time[nop];
int pc=0, tot_time=0, hp; //no. of processes completed, total time the processor has been in use, minimum arrival time
do{
	hp = highest_priority(nop,prcs,tot_time);//highest priority
	if(hp!= -2)//process is there to execute
	{
		gantt[pc].process_ID = prcs[hp].process_ID;
		gantt[pc].st_time=tot_time;
		tot_time+=prcs[hp].burst_time;
		gantt[pc].end_time= tot_time;
		waiting_time[hp]=gantt[pc].st_time - prcs[hp].arr_time;
		turnaround_time[hp]=waiting_time[hp] + prcs[hp].burst_time;
		prcs[hp].arr_time= (prcs[hp].arr_time) - 1000 ;//to indicate prcs is complete
		++pc;
	}
}while(pc!=nop);
for(int i=0;i<nop;i++)
{
    prcs[i].arr_time+=1000;
}
printf("**************************** PRIORITY(NON_PREEMPTIVE) *********************************");
print_gantt(gantt,nop);
print_table(nop,prcs,waiting_time,turnaround_time);
}

void reset_burst_arr_time(int nop, process *prcs, int *arr_time, int *burst_time){
    int i;
    for(i=0;i<nop;i++)
    {
        prcs[i].arr_time=arr_time[i];
        prcs[i].burst_time=burst_time[i];
    }
}


void priority_P(int nop, process *prcs)
{
gantt_chart gantt[20];
int waiting_time[nop], turnaround_time[nop],arrival_time[nop],burst_time[nop],executing_prcs[nop];
int pc=-1, tot_time=0, hp=-2, hpp, cnt=0, flag=0; //no. of processes in the gantt chart, total time the processor has been in use, shortest job, previous shortest job, counts the no. of prcs that has started its execution
do{
    hpp=hp;
	hp = highest_priority(nop,prcs,tot_time);//shortest job
	for(int i=0; i<cnt;i++)
    {
        if(hp!=-2 && executing_prcs[i]==prcs[hp].process_ID)
        {
            flag=1; break;//already executing/executed
        }
        else
            flag=0;
    }
	if(hp!= -2)//process is there to execute
	{
	    if(hp!=hpp)
        {
            if(pc!=-1)
            {
            gantt[pc].end_time=tot_time;
            }
            pc++;
            if(flag==0)//first time the prcs is executing
            {
                arrival_time[hp]=prcs[hp].arr_time;
                burst_time[hp]=prcs[hp].burst_time;
                executing_prcs[cnt++]=prcs[hp].process_ID;
            }
            gantt[pc].process_ID = prcs[hp].process_ID;
            gantt[pc].st_time=tot_time;
        }
        tot_time+=1;//check if any process has arrived next second

        prcs[hp].burst_time-=1;
        if(prcs[hp].burst_time==0)
        {
            prcs[hp].arr_time-=1000;
        }
    }
}while(hp!=-2);
gantt[pc].end_time=tot_time;
++pc;
reset_burst_arr_time(nop,prcs,arrival_time,burst_time);
for(int i=0;i<nop;i++)
{
    int prev_et=0;
    waiting_time[i]=-1*(prcs[i].arr_time);
    for(int j=0;j<pc;j++)
    {
        if(prcs[i].process_ID==gantt[j].process_ID)
        {
            waiting_time[i]+=(gantt[j].st_time-prev_et);
            prev_et=gantt[j].end_time;
        }
    }
    turnaround_time[i]=waiting_time[i]+burst_time[i];
}

printf("**************************** PRIORITY(PREEMPTIVE) *********************************");
print_gantt(gantt,pc);
print_table(nop,prcs,waiting_time,turnaround_time);
}

void priority(int nop, process *prcs)
{
int choice;
do
{
printf("\n\nPRIORITY MENU:\n1. Non-preemptive \n2. Preemptive \n3. Go back to main menu\nEnter choice: ");
scanf("%d",&choice);
switch(choice)
{
    case 1:
            priority_NP(nop,prcs);
            break;
    case 2:
            priority_P(nop,prcs);
            break;
    case 3:
            break;
    default:
            printf("Incorrect choice! Try again");
}
}while(choice!=3);
}

int min_arr_time(process *prcs, int nop, int tot_time)//minimum arrival time
{
	int i, min=-2;
	for(i=0;i<nop;i++)
    {
        if(min == -2)  // to find a process that has not yet been completed
		{
			if(prcs[i].arr_time >= 0 && prcs[i].arr_time<= tot_time)
				min=i;
		}
		else if(prcs[i].arr_time >0 && prcs[i].arr_time < prcs[min].arr_time)
            		min=i;
	}
	return min;
}

int in_exec_prcs(int prcs_ID, int *exec_prcs,int ep)
{
    for(int i=0; i<ep; i++)
    {
        if(prcs_ID==exec_prcs[i])
            return 1;
    }
    return 0;
}

int update_ready_queue(int nop, process *prcs, queue ready_queue, int *executing_prcs, int ep, int tot_time, int *burst_time, int *arr_time)
{
    int min=-2;
    while(1)
    {
        min=min_arr_time(prcs,nop,tot_time);
        if(min!=-2 && !in_exec_prcs(prcs[min].process_ID,executing_prcs,ep))
        {
            executing_prcs[ep++]=prcs[min].process_ID;
            enqueue(ready_queue,min);
            arr_time[min]=prcs[min].arr_time;
            prcs[min].arr_time-=1000;
            burst_time[min]=prcs[min].burst_time;
        }
        else
            break;
    }
    return ep;
}

void RR(int nop, process *prcs)
{
gantt_chart gantt[30];
int waiting_time[nop], turnaround_time[nop],arrival_time[nop],burst_time[nop],executing_prcs[nop],tot_time=0;
int q;
printf("Enter time quantum:");
scanf("%d",&q);
int pc=-1, qcount=0, ep=0, cnt=0,exe=0;
queue ready_queue=createqueue(50);
int min;
while(exe!=nop)
{
    if(pc==-1)
       ep=update_ready_queue(nop,prcs,ready_queue,executing_prcs,ep,tot_time,burst_time,arrival_time);
		
    if(ready_queue->size==-1)
    {
        tot_time+=1;
        continue;
    }
	min=dequeue(ready_queue);
	gantt[++pc].process_ID=prcs[min].process_ID;
    gantt[pc].st_time=tot_time;
    if(prcs[min].burst_time<=q)
    {
        ep=update_ready_queue(nop,prcs,ready_queue,executing_prcs,ep,tot_time,burst_time,arrival_time);
		tot_time+=prcs[min].burst_time;
        prcs[min].burst_time=0;
        ++exe;
    }
    else
    {
        prcs[min].burst_time-=q;
        tot_time+=q;
        ep=update_ready_queue(nop,prcs,ready_queue,executing_prcs,ep,tot_time,burst_time,arrival_time);
		enqueue(ready_queue,min);
    }
    gantt[pc].end_time= tot_time;

}
reset_burst_arr_time(nop,prcs,arrival_time,burst_time);
for(int i=0;i<nop;i++)
{
    int prev_et=0;
    waiting_time[i]=-1*(prcs[i].arr_time);
    for(int j=0;j<=pc;j++)
    {
        if(prcs[i].process_ID==gantt[j].process_ID)
        {
            waiting_time[i]+=(gantt[j].st_time-prev_et);
            prev_et=gantt[j].end_time;
        }
    }
    turnaround_time[i]=waiting_time[i]+burst_time[i];

}
printf("**************************** ROUND ROBIN *********************************");
print_gantt(gantt,pc+1);
print_table(nop,prcs,waiting_time,turnaround_time);
}
void main()
{
int nop, choice;
printf("\t\tPROCESS SCHEDULING\n");
printf("Enter no. of processes(<=10):");
scanf("%d",&nop);
process p[nop];
for(int i=0; i<nop;i++)
{
	printf("\nPROCESS %d-\n",i+1);
	p[i].process_ID = i+1;
	printf("Arrival time:");
	scanf("%d",&p[i].arr_time);
	printf("Burst time:");
	scanf("%d",&p[i].burst_time);
	printf("Priority:");
	scanf("%d",&p[i].priority);
}
do
{
printf("\n\tMAIN MENU:\n1. Priority\n2. Round Robin\n3. EXIT\nEnter your choice: ");
scanf("%d",&choice);
switch(choice)
{
	case 1:
		priority(nop,p);
		break;
	case 2:
		RR(nop,p);
		break;
	case 3:
	    break;
	default:
		printf("Incorrect choice!\n");
}
}while(choice!=3);
}

