#include<stdio.h>
#include<stdlib.h>

typedef struct queuerecord* queue;
typedef int elementtype;
#define minqueuesize 5
struct queuerecord
{
int capacity;
int front;
int rear;
int size;
elementtype *array;
};

int isempty (queue q)
{
return q->size == 0;
}
void makeempty(queue q)
{
q->size = 0;
q->front = -1;
q->rear = -1;
}

int isfull (queue q)
{
return q->size == q->capacity;
}

queue createqueue(int maxelements) 
{
queue q;
if (maxelements<minqueuesize)
{	printf("Queue size is too small\n");
	exit(0);
}
q=(queue)malloc(sizeof(struct queuerecord));
if(q==NULL)
{	printf("Out of space!\n");
	exit(0);
}
q->array=(elementtype *)malloc(sizeof(elementtype) * maxelements);
if(q->array == NULL)
{	printf("Out of space!\n");
	exit(0);
}
q->capacity = maxelements;
makeempty(q);
return q;
}

void disposequeue(queue q)
{
if(q!=NULL)
{
free(q->array);
free(q);
}
}
void displayQueue(queue q)
{
int i=q->front;
printf("front->");
if(q->front!=q->rear)
{
while(i!=q->rear)
{	printf("%d ",q->array[i]);
	i++;
}
printf("%d <-rear\n",q->array[i]);
}
else if(q->front==q->rear&&q->front!=-1)
	printf("%d<-rear \n",q->array[q->front]);
	
}


void enqueue(queue q, elementtype item)
{
if(isfull(q))
{
printf("Queue is full.Could not enqueue.\n");
}
else
{
if(q->rear+1==q->capacity)
	q->rear=0;
else
	q->rear++;
q->array[q->rear]=item;
if(q->front==-1)
	q->front=0;
++q->size;
}
}

elementtype dequeue(queue q)
{
elementtype data;
if(isempty(q))
{
printf("Queue is empty\n");
return 0;
}
else
{
data = q->array[q->front];
q->array[q->front]=0;
if(q->front==q->rear)
	makeempty(q);
else
{
	if(q->front+1 == q->capacity)
		q->front=0;
	else
		q->front++;
}
q->size--;
return data;
}

}

