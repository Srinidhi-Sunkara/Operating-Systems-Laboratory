#include<stdio.h>
#include<stdlib.h>
struct proc
{
 int pid;
 int bt;
 int at;
 char name[20];
 int wait_time;
 int turn_time;
 int cbt;
 int st;
};

void input(struct proc p[],int n)
{
 for(int i=0;i<n;i++)
 {
 printf("Enter the Process id:");
 scanf("%d",&p[i].pid);
 printf("Enter the arrival time in sec:");
 scanf("%d",&p[i].at);
 printf("Enter the burst time in sec:");
 scanf("%d",&p[i].bt);
p[i].cbt=p[i].bt;
 printf("Enter the name:");
 scanf(" %s",p[i].name);
 }
}
void calc(struct proc p[],int n)
{
 p[0].wait_time=0;
 int j;
  for(int i=1;i<n;i++)
  {
   j=i-1;
   
      p[i].wait_time=p[j].bt+p[j].wait_time - p[i].at ;
       j--;
    
  }
 for(int i=0;i<n;i++)
{
  p[i].turn_time=p[i].wait_time+p[i].bt;
}

}
void display(struct proc p[],int n)
{
 float avg_wait,avg_tat;
 int t=0,tt=0,iti=0;
printf("Process id  Process_name  Arrival_Time  Burst time  Turn Around  Waittime\n");
  for(int i=0;i<n;i++)
  {
printf("  %d           %s            %d            %d           %d           %d\n",p[i].pid,p[i].name,p[i].at,p[i].bt,p[i].turn_time,p[i].wait_time);
  }  
 for(int i=0;i<n;i++)
   { t+=p[i].wait_time;
     tt+=p[i].turn_time;  }
  avg_wait=t/n;
  avg_tat=tt/n;
   printf("\nAvg wait time=%f\n",avg_wait);
   printf("\nAvg turn around time=%f\n",avg_tat);
  printf("GANTT CHART:\n|");
  for(int l=0;l<n;l++)
  printf("p%d\t|",p[l].pid);
  printf("\n|");
  for(int l=0;l<n;l++)
  printf("  \t|");
 printf("\n%d",iti);
   for(int l=0;l<n;l++)
 { iti+=p[l].bt;
   printf("\t%d",iti);  } 
  printf("\n");
}
void sjfs_order(struct proc p[],int n)
{
 struct proc key;
 int j;
 for(int i=1;i<n;i++)
 {
   key=p[i];
   j=i-1;
   while(j>=0 && p[j].at > key.at)
   {
     p[j+1]=p[j];
     j=j-1;
   }
   p[j+1]=key;
  }
}

void sjfnp(struct proc p[],int n)
{
  struct proc temp;
  for(int i=0;i<n;i++)
  {
     for(int j=i+1;j<n;j++)
      {
          if(p[i].at==p[j].at && p[j].bt<p[i].bt)
          {
             temp=p[i];
              p[i]=p[j]; 
              p[j]=temp;
          }
       }
   }
}

void sjfsort(struct proc p[], int n, int wt[]) 
{ 
    int rt[n]; 

    for (int i = 0; i < n; i++) 
        rt[i] = p[i].bt; 
    int complete = 0, t = 0, minm = 999; 
    int shortest = 0, finish_time,prev=0; 
    int check = 0; 
  
//printf("t(s)  Process id   Process_name   Arrival_Time  Burst time  \n");
printf("GANTT CHART:\n");

    while (complete != n) { 
  
        for (int j = 0; j < n; j++) { 
            if ((p[j].at <= t) && 
            (rt[j] < minm) && rt[j] > 0) { 
                minm = rt[j]; 
                shortest = j; 
                check = 1; 
            } 
        } 
  if(t<1) 
    printf("0---p%d---",p[shortest].pid);
        if (check == 0) { 
            t++; 
            continue; 
        } 
 
if(p[prev].pid!=p[shortest].pid)
//printf(" %d     %d           %s              %d            %d\n",t,p[shortest].pid,p[shortest].name,p[shortest].at,rt[shortest]);
  printf("%d---p%d---",t,p[shortest].pid);  
prev=shortest;
        rt[shortest]--; 
        minm = rt[shortest]; 
        if (minm == 0) 
            minm = 999; 
        if (rt[shortest] == 0) { 
            complete++; 
            check = 0; 
            finish_time = t + 1; 
            wt[shortest] = finish_time -p[shortest].bt -p[shortest].at; 
  
            if (wt[shortest] < 0) 
                wt[shortest] = 0; 
        } 
 
        t++; 
    }
 printf("%d\n",t);
} 

void ta_time(struct proc p[],int n,int wt[],int tat[]) 
{ 

    for (int i = 0; i < n; i++) 
        tat[i] = p[i].bt + wt[i]; 
} 

void sjfm(struct proc p[], int n) 
{ 
    int wt[n], tat[n], total_wt = 0,total_tat = 0; 
  
    sjfsort(p, n, wt); 
  
    ta_time(p, n, wt, tat); 
  

printf("Process id  Process_name  Arrival_Time  Burst time  Turn Around  Waittime\n");
  for(int i=0;i<n;i++)
  {
 total_wt = total_wt + wt[i]; 
 total_tat = total_tat + tat[i]; 
 printf("  %d           %s            %d            %d           %d           %d\n",p[i].pid,p[i].name,p[i].at,p[i].bt,tat[i],wt[i]);
  }  
    printf("\nAverage waiting time =%f ",(float)total_wt / (float)n); 
    printf( "\nAverage turn around time = %f\n",(float)total_tat / (float)n); 
} 

void main()
{ int ch=0;
 do
 {
 int n,a=0,i=0,t;
 printf("Enter the no.of processes:");
 scanf("%d",&n);
 struct proc p[10];
printf("Choose the Scheduling method:\n");
 printf("1.FCFS\n2.SJF-NP\n3.SJF-P\n4.Exit\n");
 scanf("%d",&ch);
   switch(ch)
   {
     case 1: 
          input(p,n);
          sjfs_order(p,n);
          calc(p,n);
          display(p,n);
          break;
     case 2:
          input(p,n);
          sjfs_order(p,n);
          sjfnp(p,n);
          calc(p,n);
          display(p,n);
          break;
     case 3:
          input(p,n);
          sjfm(p,n);
          break;
     case 4:
          printf("Thank you!\n");
          break;
   }
}while(ch!=4);
}

