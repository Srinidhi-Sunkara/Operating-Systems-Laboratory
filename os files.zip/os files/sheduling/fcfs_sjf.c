//to implement process scheduling algorithms - FCFS, SJF
#include<stdio.h>
#include<stdlib.h>

typedef struct{
	int process_ID;
	int arr_time;
	int burst_time;
}process;

typedef struct{
	int process_ID;
	int st_time;
	int end_time;
}gantt_chart;

int min_arr_time(process *prcs, int nop)//minimum arrival time
{
	int i, min=-2;
	for(i=0;i<nop;i++)
	{
		if(min == -2)  // to find a process that has not yet been completed
		{
			if(prcs[i].arr_time >= 0)
				min=i;
		}
		else if(prcs[i].arr_time >0 && prcs[i].arr_time < prcs[min].arr_time)
            		min=i;
	}
	return min;
}

void print_gantt(gantt_chart *gantt, int nop)
{
    int i;
	printf("\nGANTT CHART-\n");
    for(i=0;i<nop;i++)
    {
        if(i!=0 && gantt[i].st_time==gantt[i-1].end_time)
            printf("|P%d\t",gantt[i].process_ID);
        else if(i!=0)
            printf("|\t|P%d\t",gantt[i].process_ID);
        else
            printf("|P1\t");
    }
    printf("|\n0");
	for(i=0; i<nop;i++)
	{
        if(i!=0 && gantt[i].st_time==gantt[i-1].end_time)
            printf(" \t%d ",gantt[i].end_time);
        else if(i!=0)
            printf(" \t%d\t%d ",gantt[i].st_time,gantt[i].end_time);
        else
            printf(" \t%d ",gantt[i].end_time);
	}
	printf("\n\n");
}

void print_table(int nop, process *prcs, int *waiting_time, int *turnaround_time)
{
	int i,tot_waiting_time=0, tot_turnaround_time=0;
	printf("\nPROCESS TABLE-\n");
    printf(" _______________________________________________________________\n");
    printf("|PROCESS ID|ARRIVAL TIME|BURST TIME|WAITING TIME|TURNAROUND TIME|\n");
    printf("|__________|____________|__________|____________|_______________|\n");
    for(i=0;i<nop;i++)
    {
        printf("|P%-9d|%12d|%10d|%12d|%15d|\n",
                prcs[i].process_ID,
                prcs[i].arr_time,
                prcs[i].burst_time,
                waiting_time[i],
                turnaround_time[i]);
		tot_waiting_time+=waiting_time[i];
		tot_turnaround_time+=turnaround_time[i];
    }
	printf(" _______________________________________________________________\n\n");
	printf("Average Waiting Time:%-10.2f\n",tot_waiting_time/5.0);
	printf("Average Turnaround Time:%-10.2f\n\n",tot_turnaround_time/5.0);

}

void FCFS(int nop, process *prcs)
{
	int i;
gantt_chart gantt[nop];
int waiting_time[nop], turnaround_time[nop];
int pc=0, tot_time=0, mat; //no. of processes completed, total time the processor has been in use, minimum arrival time
do{
	mat = min_arr_time(prcs,nop);//min arrival time
	if(mat!= -2)//process is there to execute
	{
        gantt[pc].process_ID = prcs[mat].process_ID;
		if(tot_time<prcs[mat].arr_time)
            	tot_time=prcs[mat].arr_time;
		gantt[pc].st_time=tot_time;
		tot_time+=prcs[mat].burst_time;
		gantt[pc].end_time= tot_time;
        	waiting_time[mat]=gantt[pc].st_time - prcs[mat].arr_time;//since arr_time will be set as -ve after the process is complete
		turnaround_time[mat]=waiting_time[mat] + prcs[mat].burst_time;
		prcs[mat].arr_time= (prcs[mat].arr_time) - 1000 ;//to indicate prcs is complete
		++pc;
	}
}while(pc!=nop);
for(i=0;i<nop;i++)
{
    prcs[i].arr_time+=1000;
}
printf("**************************** FCFS *********************************");
print_gantt(gantt,nop);
print_table(nop,prcs,waiting_time,turnaround_time);
}

int shortest_job(int nop, process *prcs, int tot_time){
    int sj=-2,i;
    for(i=0;i<nop;i++)
    {
        if(prcs[i].arr_time>-1 && (tot_time - prcs[i].arr_time)>=0)
        {
            if(sj!=-2 && prcs[i].burst_time < prcs[sj].burst_time)
                sj=i;
            else if(sj==-2)
                sj=i;
        }
    }
    return sj;
}

void SJF_NP(int nop, process *prcs)
{
	int i;
gantt_chart gantt[nop];
int waiting_time[nop], turnaround_time[nop];
int pc=0, tot_time=0, sj; //no. of processes completed, total time the processor has been in use, minimum arrival time
do{
	sj = shortest_job(nop,prcs,tot_time);//shortest job
	if(sj!= -2)//process is there to execute
	{
		gantt[pc].process_ID = prcs[sj].process_ID;
		gantt[pc].st_time=tot_time;
		tot_time+=prcs[sj].burst_time;
		gantt[pc].end_time= tot_time;
        waiting_time[sj]=gantt[pc].st_time - prcs[sj].arr_time;
		turnaround_time[sj]=waiting_time[sj] + prcs[sj].burst_time;
		prcs[sj].arr_time= (prcs[sj].arr_time) - 1000 ;//to indicate prcs is complete
		++pc;
	}
}while(pc!=nop);
for(i=0;i<nop;i++)
{
    prcs[i].arr_time+=1000;
}
printf("**************************** SJF(NON-PREEMPTIVE) *********************************");
print_gantt(gantt,nop);
print_table(nop,prcs,waiting_time,turnaround_time);
}

int check_prcs_arrival(int nop,process *prcs,int tot_time,int sj)
{
    int i;
    for(i=0;i<nop;i++){
       if(prcs[i].arr_time>-1 && prcs[i].arr_time<=tot_time)
        {
            if(prcs[i].burst_time< prcs[sj].burst_time)
                break;
        }
    }
    if(i==nop)
        return -1;
    return i;
}

void reset_burst_arr_time(int nop, process *prcs, int *arr_time, int *burst_time){
    int i;
    for(i=0;i<nop;i++)
    {
        prcs[i].arr_time=arr_time[i];
        prcs[i].burst_time=burst_time[i];
    }
}
void SJF_P(int nop,process *prcs){
gantt_chart gantt[20];
int i,j;
int waiting_time[nop], turnaround_time[nop],arrival_time[nop],burst_time[nop],executing_prcs[nop];
int pc=-1, tot_time=0, sj=-2, sjp, cnt=0, flag=0; //no. of processes in the gantt chart, total time the processor has been in use, shortest job, previous shortest job, counts the no. of prcs that has started its execution
do{
    sjp=sj;
	sj = shortest_job(nop,prcs,tot_time);//shortest job
	for(i=0; i<cnt;i++)
    {
        if(sj!=-2 && executing_prcs[i]==prcs[sj].process_ID)
        {
            flag=1; break;//already executing/executed
        }
        else
            flag=0;
    }
	if(sj!= -2)//process is there to execute
	{
	    if(sj!=sjp)
        {
            if(pc!=-1)
            {
            gantt[pc].end_time=tot_time;
            }
            pc++;
            if(flag==0)//first time the prcs is executing
            {
                arrival_time[sj]=prcs[sj].arr_time;
                burst_time[sj]=prcs[sj].burst_time;
                executing_prcs[cnt++]=prcs[sj].process_ID;
            }
            gantt[pc].process_ID = prcs[sj].process_ID;
            gantt[pc].st_time=tot_time;
        }
        tot_time+=1;//check if any process has arrived next second

        prcs[sj].burst_time-=1;
        if(prcs[sj].burst_time==0)
        {
            prcs[sj].arr_time-=1000;
        }
    }
}while(sj!=-2);
gantt[pc].end_time=tot_time;
++pc;
reset_burst_arr_time(nop,prcs,arrival_time,burst_time);
for(i=0;i<nop;i++)
{
    int prev_et=0;
    waiting_time[i]=-1*(prcs[i].arr_time);
    for(j=0;j<pc;j++)
    {
        if(prcs[i].process_ID==gantt[j].process_ID)
        {
            waiting_time[i]+=(gantt[j].st_time-prev_et);
            prev_et=gantt[j].end_time;
        }
    }
    turnaround_time[i]=waiting_time[i]+burst_time[i];
}
printf("**************************** SJF(PREEMPTIVE) *********************************");
print_gantt(gantt,pc);
print_table(nop,prcs,waiting_time,turnaround_time);
}

void SJF(int nop, process *prcs)
{
int choice;
do
{
printf("\n\nSJF MENU:\n1. Non-preemptive \n2. Preemptive \n3. Go back to main menu\nEnter choice: ");
scanf("%d",&choice);
switch(choice)
{
    case 1:
            SJF_NP(nop,prcs);
            break;
    case 2:
            SJF_P(nop,prcs);
            break;
    case 3:
            break;
    default:
            printf("Incorrect choice! Try again");
}
}while(choice!=3);
}


void main()
{
int i,nop, choice;
printf("\t\tPROCESS SCHEDULING\n");
printf("Enter no. of processes(<=10):");
scanf("%d",&nop);
process p[nop];
for(i=0; i<nop;i++)
{
	printf("\nPROCESS %d-\n",i+1);
	p[i].process_ID = i+1;
	printf("Arrival time:");
	scanf("%d",&p[i].arr_time);
	printf("Burst time:");
	scanf("%d",&p[i].burst_time);
}
do
{
printf("\n\tMAIN MENU:\n1. FCFS\n2. SJF\n3. EXIT\nEnter your choice: ");
scanf("%d",&choice);
switch(choice)
{
	case 1:
		FCFS(nop,p);
		break;
	case 2:
	    SJF(nop,p);
		break;
	case 3:
	    break;
	default:
		printf("Incorrect choice!\n");
}
}while(choice!=3);
}
