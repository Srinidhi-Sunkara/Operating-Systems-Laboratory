/*#include<stdio.h>
struct process{
	int at,bt,r,id;
}p[10];
void main()
{
	struct process temp;
	int n,l,runtime=0,i,j,total=0,m=0,a[100],b[10],s=0;//in a im storing pid and in b time
	printf("enter the number of process:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter the arrival time:");
		scanf("%d",&p[i].at);
		printf("enter the burst time:");
		scanf("%d",&p[i].bt);
	//	printf("enter the priority: ");
	//	scanf("%d",&p[i].pr);
		p[i].r=1;
		total+=p[i].bt;	
		p[i].id=i+1;	
	}
//	printf("%d \n",total);
	while(runtime<total)
	{
		l=0;
		for(i=0;i<n;i++)
		{
			if(p[i].at<=runtime && p[i].r!=2)
			{
				p[i].r=0;
				l++;
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(p[i].r>p[j].r)
				{
					temp=p[i];
					p[i]=p[j];
					p[j]=temp;
				}
			}
		}
		for(i=0;i<l;i++)
		{
			for(j=i+1;j<l;j++)
			{
				if(p[i].bt>p[j].bt)
				{
					temp=p[i];
					p[i]=p[j];
					p[j]=temp;
				}
			}
		}
		a[runtime]=p[0].id;//assigning id
		if(runtime==0)
		{
			printf("|   P%d  |",a[runtime]);
			b[0]=p[0].at;
			m=runtime;//previous runtime
			
		}
		
		if(a[m]!=a[runtime])
		{
			printf("|   P%d  |",a[runtime]);
			s=s+1;
			b[s]=runtime;
			m=runtime;
		}
		
		p[0].bt--;
		
		if(p[0].bt==0)
		p[0].r=2;
		//printf("\ndetails : pid :%d,arrival time: %d, current time:%d, current burst time :%d , status:%d",p[0].id,p[0].at,runtime,p[0].bt,p[0].r);
		runtime++;
		
	
	}
	
	printf("\n");
	s=s+1;
	b[s]=total;
	//printf("%d nt",b[s+1]);
		for(i=0;i<s+1;i++)
	{
		printf("%d        ",b[i]);
	}


	
	
}*/
/*
#include<stdio.h>
struct process{
	int at,bt,r,id;
}p[10];
void main()
{
	struct process temp;
	int n,l,runtime=0,i,j,total=0,m=0,a[100],b[10],s=0,wt=0,tt=0;//in a im storing pid and in b time
	float att,awt;
	printf("enter the number of process:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter the arrival time:");
		scanf("%d",&p[i].at);
		printf("enter the burst time:");
		scanf("%d",&p[i].bt);
	//	printf("enter the priority: ");
	//	scanf("%d",&p[i].pr);
		p[i].r=1;
		total+=p[i].bt;	
		p[i].id=i+1;	
	}
//	printf("%d \n",total);
	while(runtime<total)
	{
		l=0;
		for(i=0;i<n;i++)
		{
			if(p[i].at<=runtime && p[i].r!=2)
			{
				p[i].r=0;
				l++;
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(p[i].r>p[j].r)
				{
					temp=p[i];
					p[i]=p[j];
					p[j]=temp;
				}
			}
		}
		for(i=0;i<l;i++)
		{
			for(j=i+1;j<l;j++)
			{
				if(p[i].bt>p[j].bt)
				{
					temp=p[i];
					p[i]=p[j];
					p[j]=temp;
				}
			}
		}
		a[runtime]=p[0].id;//assigning id
		if(runtime==0)
		{
			printf("|   P%d  |",a[runtime]);
			b[0]=p[0].at;
			m=runtime;//previous runtime
			
		}
		
		if(a[m]!=a[runtime])
		{
			printf("|   P%d  |",a[runtime]);
			s=s+1;
			b[s]=runtime;
			m=runtime;
		}
		
		//p[0].bt--;
		runtime=runtime+p[0].bt;
		wt+=runtime-p[0].at-p[0].bt;
		tt+=runtime-p[0].at;
		p[0].bt=0;
		p[0].r=2;
		//printf("\ndetails : pid :%d,arrival time: %d, current time:%d, current burst time :%d , status:%d",p[0].id,p[0].at,runtime,p[0].bt,p[0].r);
		
		
	
	}
	
	printf("\n");
	s=s+1;
	b[s]=total;
	//printf("%d nt",b[s+1]);
		for(i=0;i<s+1;i++)
	{
		printf("%d        ",b[i]);
	}
	printf("\ntwt %d",wt);
	printf("\n ttt %d",tt);
	att=(tt*1.0)/n;
	awt=(wt*1.0)/n;
	printf("\n awt %f",awt);
	printf("\n att %f",att);


	
	
}*/
/*
#include<stdio.h>
struct process{
	int at,bt,r,id,pr;
}p[10];
void main()
{
	struct process temp;
	int n,l,runtime=0,i,j,total=0,m=0,a[100],b[10],s=0,wt=0,tt=0;//in a im storing pid and in b time
	float att,awt;
	printf("enter the number of process:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("enter the arrival time:");
		scanf("%d",&p[i].at);
		printf("enter the burst time:");
		scanf("%d",&p[i].bt);
		printf("enter the priority: ");
		scanf("%d",&p[i].pr);
		p[i].r=1;
		total+=p[i].bt;	
		p[i].id=i+1;	
	}
//	printf("%d \n",total);
	while(runtime<total)
	{
		l=0;
		for(i=0;i<n;i++)
		{
			if(p[i].at<=runtime && p[i].r!=2)
			{
				p[i].r=0;
				l++;
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(p[i].r>p[j].r)
				{
					temp=p[i];
					p[i]=p[j];
					p[j]=temp;
				}
			}
		}
		for(i=0;i<l;i++)
		{
			for(j=i+1;j<l;j++)
			{
				if(p[i].pr>p[j].pr)
				{
					temp=p[i];
					p[i]=p[j];
					p[j]=temp;
				}
			}
		}
		a[runtime]=p[0].id;//assigning id
		if(runtime==0)
		{
			printf("|   P%d  |",a[runtime]);
			b[0]=p[0].at;
			m=runtime;//previous runtime
			
		}
		
		if(a[m]!=a[runtime])
		{
			printf("|   P%d  |",a[runtime]);
			s=s+1;
			b[s]=runtime;
			m=runtime;
		}
		
		//p[0].bt--;
		runtime=runtime+p[0].bt;
		wt+=runtime-p[0].at-p[0].bt;
		tt+=runtime-p[0].at;
		p[0].bt=0;
		p[0].r=2;
		//printf("\ndetails : pid :%d,arrival time: %d, current time:%d, current burst time :%d , status:%d",p[0].id,p[0].at,runtime,p[0].bt,p[0].r);
		
		
	
	}
	
	printf("\n");
	s=s+1;
	b[s]=total;
	//printf("%d nt",b[s+1]);
		for(i=0;i<s+1;i++)
	{
		printf("%d        ",b[i]);
	}
	printf("\ntwt %d",wt);
	printf("\n ttt %d",tt);
	att=(tt*1.0)/n;
	awt=(wt*1.0)/n;
	printf("\n awt %f",awt);
	printf("\n att %f",att);


	
	
}*/

